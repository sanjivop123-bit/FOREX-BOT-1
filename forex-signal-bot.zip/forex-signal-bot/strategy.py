import pandas as pd
import config


def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def rsi(close, n=14):
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    rs = up / dn.replace(0, 1e-12)
    return 100 - 100 / (1 + rs)


def atr(df, n=14):
    pc = df["close"].shift(1)
    tr = pd.concat([df["high"] - df["low"],
                    (df["high"] - pc).abs(),
                    (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def decimals(symbol):
    if "JPY" in symbol:
        return 3
    if symbol.startswith("XAU") or symbol.startswith("XAG"):
        return 2
    return 5


def analyze(symbol, df):
    """Return a signal dict or None. Uses closed candles only."""
    df = df.iloc[:-1].copy()  # drop the still-forming candle
    if len(df) < 210:
        return None

    close = df["close"]
    df["ema20"] = ema(close, 20)
    df["ema50"] = ema(close, 50)
    df["ema200"] = ema(close, 200)
    df["rsi"] = rsi(close)
    macd = ema(close, 12) - ema(close, 26)
    df["hist"] = macd - ema(macd, 9)
    df["atr"] = atr(df)

    last = df.iloc[-1]
    hist = df["hist"].iloc[-4:]
    slope = df["ema50"].iloc[-1] - df["ema50"].iloc[-6]

    up_trend = last.ema50 > last.ema200 and last.close > last.ema50
    down_trend = last.ema50 < last.ema200 and last.close < last.ema50
    cross_up = hist.iloc[-1] > 0 and hist.iloc[:-1].min() <= 0
    cross_down = hist.iloc[-1] < 0 and hist.iloc[:-1].max() >= 0

    direction, score = None, 0
    if up_trend and cross_up:
        direction = "BUY"
        score = 3
        score += 1 if 45 < last.rsi < 70 else 0
        score += 1 if slope > 0 and last.close > last.ema20 else 0
    elif down_trend and cross_down:
        direction = "SELL"
        score = 3
        score += 1 if 30 < last.rsi < 55 else 0
        score += 1 if slope < 0 and last.close < last.ema20 else 0
    if direction is None or score < config.MIN_SCORE:
        return None

    entry, a = float(last.close), float(last.atr)
    sgn = 1 if direction == "BUY" else -1
    d = decimals(symbol)
    return {
        "symbol": symbol,
        "direction": direction,
        "entry": round(entry, d),
        "sl": round(entry - sgn * a * config.ATR_SL_MULT, d),
        "tp1": round(entry + sgn * a * config.ATR_TP1_MULT, d),
        "tp2": round(entry + sgn * a * config.ATR_TP2_MULT, d),
        "score": score,
        "rsi": round(float(last.rsi), 1),
        "candle_time": last.datetime,
        "timeframe": config.INTERVAL,
    }
