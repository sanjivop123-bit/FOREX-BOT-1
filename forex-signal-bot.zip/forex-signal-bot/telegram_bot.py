import requests
import config


def send(text: str) -> bool:
    if not config.TELEGRAM_BOT_TOKEN or not config.TELEGRAM_CHAT_ID:
        print("Telegram not configured:", text)
        return False
    url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage"
    try:
        r = requests.post(url, json={
            "chat_id": config.TELEGRAM_CHAT_ID,
            "text": text,
            "parse_mode": "HTML",
        }, timeout=20)
        if not r.ok:
            print("Telegram error:", r.text)
        return r.ok
    except Exception as e:
        print("Telegram exception:", e)
        return False


def format_signal(s: dict) -> str:
    icon = "🟢" if s["direction"] == "BUY" else "🔴"
    stars = "⭐" * s["score"]
    return (
        f"{icon} <b>{s['direction']} {s['symbol'].replace('/', '')}</b>  ({s['timeframe']})\n"
        f"Strength: {stars} ({s['score']}/5)\n\n"
        f"Entry: <code>{s['entry']}</code>\n"
        f"SL: <code>{s['sl']}</code>\n"
        f"TP1: <code>{s['tp1']}</code>\n"
        f"TP2: <code>{s['tp2']}</code>\n"
        f"RSI: {s['rsi']}\n\n"
        f"⚠️ Risk 1% per trade max. Not financial advice."
    )
