import threading
import time
from datetime import datetime, timezone, timedelta

from flask import Flask, jsonify

import config
from data import fetch_candles
from strategy import analyze
import telegram_bot

app = Flask(__name__)

state = {"last_scan": None, "last_error": None, "signals_sent": 0, "scans": 0}
last_sent = {}  # symbol -> datetime of last signal
_started = False


def in_trading_hours():
    h = datetime.now(timezone.utc).hour
    return config.START_HOUR_UTC <= h < config.END_HOUR_UTC


def scan_once():
    for symbol in config.PAIRS:
        try:
            df = fetch_candles(symbol)
            sig = analyze(symbol, df)
            if sig:
                prev = last_sent.get(symbol)
                now = datetime.now(timezone.utc)
                if prev is None or now - prev >= timedelta(minutes=config.COOLDOWN_MINUTES):
                    if telegram_bot.send(telegram_bot.format_signal(sig)):
                        last_sent[symbol] = now
                        state["signals_sent"] += 1
                        print("Signal sent:", symbol, sig["direction"])
        except Exception as e:
            state["last_error"] = f"{symbol}: {e}"
            print("Error:", symbol, e)
        time.sleep(config.REQUEST_GAP_SECONDS)  # respect Twelve Data rate limit
    state["scans"] += 1
    state["last_scan"] = datetime.now(timezone.utc).isoformat()


def worker():
    telegram_bot.send("✅ Forex signal bot started.\nPairs: " + ", ".join(config.PAIRS)
                      + f"\nTimeframe: {config.INTERVAL}")
    while True:
        if in_trading_hours():
            scan_once()
        time.sleep(config.SCAN_MINUTES * 60)


def start_worker():
    global _started
    if not _started:
        _started = True
        threading.Thread(target=worker, daemon=True).start()


@app.route("/")
def home():
    return "Forex signal bot is running."


@app.route("/health")
def health():
    return jsonify(status="ok", **state)


start_worker()

if __name__ == "__main__":
    import os
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "10000")))
