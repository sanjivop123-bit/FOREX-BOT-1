import requests
import pandas as pd
import config

BASE_URL = "https://api.twelvedata.com/time_series"


def fetch_candles(symbol: str, outputsize: int = 250) -> pd.DataFrame:
    """Fetch OHLC candles from Twelve Data. Returns ascending DataFrame."""
    params = {
        "symbol": symbol,
        "interval": config.INTERVAL,
        "outputsize": outputsize,
        "apikey": config.TWELVE_API_KEY,
        "order": "ASC",
    }
    r = requests.get(BASE_URL, params=params, timeout=20)
    j = r.json()
    if j.get("status") == "error" or "values" not in j:
        raise RuntimeError(f"Twelve Data error for {symbol}: {j.get('message', j)}")
    df = pd.DataFrame(j["values"])
    for c in ("open", "high", "low", "close"):
        df[c] = df[c].astype(float)
    df["datetime"] = pd.to_datetime(df["datetime"])
    df = df.sort_values("datetime").reset_index(drop=True)
    return df
