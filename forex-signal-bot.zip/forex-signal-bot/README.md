# Forex Signal Bot (Twelve Data + Telegram + Render)

## 1. தேவையானவை
1. **Twelve Data API key** – https://twelvedata.com → Sign up → Dashboard → API Keys (Free plan: 8 req/min, 800/day).
2. **Telegram Bot Token** – Telegram-ல் @BotFather → /newbot → token copy பண்ணு.
3. **Telegram Chat ID** – உன் bot-க்கு ஒரு message அனுப்பு (/start). பிறகு @userinfobot-ல் உன் ID பார்க்கலாம். Channel-க்கு அனுப்ப வேண்டும் என்றால் bot-ஐ channel admin ஆக்கி, chat id (-100...) பயன்படுத்து.

## 2. Render-ல் Deploy
1. இந்த zip-ஐ extract பண்ணி GitHub-ல் புதிய repository-ஆக upload பண்ணு.
2. https://render.com → New → **Blueprint** (அல்லது Web Service) → GitHub repo select.
3. Environment Variables-ல் இவற்றை நிரப்பு:
   - `TWELVE_DATA_API_KEY`
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
4. Deploy. Telegram-ல் "Forex signal bot started" வந்தால் வேலை செய்கிறது.
5. Free plan 15 நிமிடம் idle ஆனால் தூங்கும். https://uptimerobot.com-ல் `https://<உன்-app>.onrender.com/health` URL-ஐ 5 நிமிடத்துக்கு ஒருமுறை ping பண்ணும்படி வை.

## 3. Strategy
- Timeframe: 15min (மாற்றலாம்: `INTERVAL`)
- Trend: EMA50 vs EMA200 + price EMA50 மேல்/கீழ்
- Entry trigger: MACD histogram சமீபத்தில் cross ஆகியிருக்க வேண்டும்
- Strength score (3–5): RSI zone, EMA50 slope, EMA20 position
- SL = 1.5×ATR, TP1 = 1.5×ATR, TP2 = 3×ATR
- `MIN_SCORE=4` → குறைவான ஆனால் வலுவான signals. 3 → அதிக signals.
- Closed candles மட்டும் பயன்படுத்தப்படும்; ஒரே pair-க்கு 60 நிமிடம் cooldown.

## 4. MT5-ல் பயன்படுத்த
Signal வந்ததும் MT5-ல் manual-ஆக order போடு (Entry/SL/TP). Pair பெயர்: `EURUSD` போன்றவை; உன் broker-ல் suffix இருக்கலாம் (EURUSDm).

## 5. Local-ஆக ஓட்ட
```
pip install -r requirements.txt
export TWELVE_DATA_API_KEY=... TELEGRAM_BOT_TOKEN=... TELEGRAM_CHAT_ID=...
python main.py
```

## 6. கவனம்
- இது எந்த லாபத்துக்கும் உத்தரவாதம் இல்லை. முதலில் demo account-ல் சோதி.
- ஒரு trade-க்கு 1% risk மட்டும்.
- Free plan-ல் 6 pairs × 15min ≈ 576 requests/day (limit 800). Pairs அதிகரித்தால் limit தாண்டும்.
