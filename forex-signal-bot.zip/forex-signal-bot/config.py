import os

TWELVE_API_KEY = os.getenv("TWELVE_DATA_API_KEY", "")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

PAIRS = [p.strip() for p in os.getenv(
    "PAIRS", "EUR/USD,GBP/USD,USD/JPY,AUD/USD,USD/CAD,XAU/USD").split(",") if p.strip()]

INTERVAL = os.getenv("INTERVAL", "15min")          # 5min, 15min, 30min, 1h ...
SCAN_MINUTES = int(os.getenv("SCAN_MINUTES", "15"))  # how often to scan
REQUEST_GAP_SECONDS = int(os.getenv("REQUEST_GAP_SECONDS", "9"))  # free plan: 8 req/min
MIN_SCORE = int(os.getenv("MIN_SCORE", "4"))        # 3..5, higher = stronger/fewer signals
COOLDOWN_MINUTES = int(os.getenv("COOLDOWN_MINUTES", "60"))  # per pair

ATR_SL_MULT = float(os.getenv("ATR_SL_MULT", "1.5"))
ATR_TP1_MULT = float(os.getenv("ATR_TP1_MULT", "1.5"))
ATR_TP2_MULT = float(os.getenv("ATR_TP2_MULT", "3.0"))

# Trading hours filter (UTC). Set both to 0 and 24 to scan all day.
START_HOUR_UTC = int(os.getenv("START_HOUR_UTC", "6"))
END_HOUR_UTC = int(os.getenv("END_HOUR_UTC", "20"))
